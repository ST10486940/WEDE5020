/* Delicious Bites Restaurant - interactive features and form validation */
document.addEventListener('DOMContentLoaded', () => {
    // Dynamic searchable and filterable meal cards.
    const menuGrid = document.getElementById('menuGrid');
    if (menuGrid) {
        const meals = [
            { name: 'Beef Burger and Fries', category: 'main', description: 'A filling beef burger served with fries.' },
            { name: 'Chicken Pizza', category: 'main', description: 'A popular chicken pizza option.' },
            { name: 'Side Dishes', category: 'side', description: 'Add a side dish to make your meal more satisfying.' },
            { name: 'Desserts', category: 'dessert', description: 'Finish your meal with something sweet.' },
            { name: 'Refreshing Drinks', category: 'drink', description: 'Enjoy a refreshing drink with your meal.' }
        ];
        const search = document.getElementById('menuSearch');
        const category = document.getElementById('menuCategory');
        const status = document.getElementById('menuStatus');
        const renderMeals = () => {
            const term = search.value.trim().toLowerCase();
            const selected = category.value;
            const filtered = meals.filter(meal => meal.name.toLowerCase().includes(term) && (selected === 'all' || meal.category === selected));
            menuGrid.replaceChildren();
            filtered.forEach(meal => {
                const card = document.createElement('article');
                card.className = 'menu-card';
                const heading = document.createElement('h3'); heading.textContent = meal.name;
                const description = document.createElement('p'); description.textContent = meal.description;
                const link = document.createElement('a'); link.href = 'enquiry.html'; link.textContent = 'Enquire about this';
                card.append(heading, description, link); menuGrid.append(card);
            });
            status.textContent = filtered.length ? `${filtered.length} menu option(s) found.` : 'No menu options match your search. Try another word or category.';
        };
        search.addEventListener('input', renderMeals);
        category.addEventListener('change', renderMeals);
        renderMeals();
    }

    // Accessible image lightbox for the gallery.
    const lightbox = document.getElementById('lightbox');
    if (lightbox) {
        const largeImage = lightbox.querySelector('.lightbox-image');
        const caption = lightbox.querySelector('.lightbox-caption');
        const closeButton = lightbox.querySelector('.lightbox-close');
        let previousFocus = null;
        document.querySelectorAll('.lightbox-trigger').forEach(trigger => {
            trigger.addEventListener('click', () => {
                const image = trigger.querySelector('img');
                previousFocus = trigger;
                largeImage.src = image.src;
                largeImage.alt = image.alt;
                caption.textContent = image.alt;
                lightbox.classList.add('is-open');
                lightbox.setAttribute('aria-hidden', 'false');
                closeButton.focus();
            });
        });
        const closeLightbox = () => {
            lightbox.classList.remove('is-open');
            lightbox.setAttribute('aria-hidden', 'true');
            largeImage.src = '';
            if (previousFocus) previousFocus.focus();
        };
        closeButton.addEventListener('click', closeLightbox);
        lightbox.addEventListener('click', event => { if (event.target === lightbox) closeLightbox(); });
        document.addEventListener('keydown', event => { if (event.key === 'Escape' && lightbox.classList.contains('is-open')) closeLightbox(); });
    }

    // Date restrictions and client-side form validation with asynchronous local demo processing.
    const today = new Date();
    const localToday = new Date(today.getTime() - today.getTimezoneOffset() * 60000).toISOString().split('T')[0];
    const dateField = document.getElementById('enquiryDate');
    if (dateField) dateField.min = localToday;

    const showResult = (element, html) => { element.innerHTML = html; element.classList.add('is-visible'); };
    const safe = value => String(value || '').replace(/[&<>"']/g, char => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[char]));
    const validPhone = value => !value || /^[0-9+()\s-]{7,20}$/.test(value);

    const contactForm = document.getElementById('contactForm');
    if (contactForm) {
        contactForm.addEventListener('submit', async event => {
            event.preventDefault();
            const error = document.getElementById('contactError');
            const result = document.getElementById('contactResult');
            error.textContent = ''; result.classList.remove('is-visible');
            const data = Object.fromEntries(new FormData(contactForm).entries());
            if (!contactForm.reportValidity()) return;
            if (!validPhone(data.phone)) { error.textContent = 'Please enter a valid phone number.'; return; }
            if (data.message.trim().length < 10) { error.textContent = 'Please enter a message containing at least 10 characters.'; return; }
            const submit = contactForm.querySelector('button[type="submit"]'); submit.disabled = true; submit.textContent = 'Preparing...';
            try {
                // Demonstration of asynchronous processing. A live server endpoint is required to email/store submissions.
                await new Promise(resolve => setTimeout(resolve, 450));
                const saved = JSON.parse(localStorage.getItem('deliciousBitesContactMessages') || '[]');
                saved.push({...data, submittedAt: new Date().toISOString()});
                localStorage.setItem('deliciousBitesContactMessages', JSON.stringify(saved));
                showResult(result, `<h3>Thank you, ${safe(data.name)}.</h3><p>Your message has passed validation and has been saved in this browser as a demonstration. Message type: <strong>${safe(data.messageType)}</strong>.</p><p><strong>Important:</strong> This static website does not send the message to the restaurant. A secure server-side form endpoint must be connected before the live site can receive messages.</p>`);
                contactForm.reset();
            } catch (err) { error.textContent = 'Your message could not be processed in this browser. Please try again.'; }
            finally { submit.disabled = false; submit.textContent = 'Prepare Message'; }
        });
    }

    const enquiryForm = document.getElementById('enquiryForm');
    if (enquiryForm) {
        enquiryForm.addEventListener('submit', async event => {
            event.preventDefault();
            const error = document.getElementById('enquiryError');
            const result = document.getElementById('enquiryResult');
            error.textContent = ''; result.classList.remove('is-visible');
            const data = Object.fromEntries(new FormData(enquiryForm).entries());
            if (!enquiryForm.reportValidity()) return;
            if (!validPhone(data.phone)) { error.textContent = 'Please enter a valid phone number.'; return; }
            if (data.details.trim().length < 10) { error.textContent = 'Please provide at least 10 characters describing your enquiry.'; return; }
            if (data.preferredDate < localToday) { error.textContent = 'Please choose today or a future date.'; return; }
            if (Number(data.guests) < 1 || Number(data.guests) > 100) { error.textContent = 'Please enter between 1 and 100 guests.'; return; }
            const submit = enquiryForm.querySelector('button[type="submit"]'); submit.disabled = true; submit.textContent = 'Processing...';
            try {
                // Demonstration of AJAX-style asynchronous processing in the browser.
                await new Promise(resolve => setTimeout(resolve, 450));
                const saved = JSON.parse(localStorage.getItem('deliciousBitesEnquiries') || '[]');
                saved.push({...data, submittedAt: new Date().toISOString()});
                localStorage.setItem('deliciousBitesEnquiries', JSON.stringify(saved));
                showResult(result, `<h3>Thank you, ${safe(data.name)}. Your enquiry is valid.</h3><ul><li><strong>Enquiry:</strong> ${safe(data.enquiryType)}</li><li><strong>Request:</strong> ${safe(data.details)}</li><li><strong>Preferred date:</strong> ${safe(data.preferredDate)}</li><li><strong>Number of people:</strong> ${safe(data.guests)}</li></ul><p>Pricing and availability depend on the requested meal, date and group size. Please contact the restaurant on <a href="tel:+27123456789">012 345 6789</a> or <a href="mailto:info@deliciousbites.co.za">info@deliciousbites.co.za</a> to confirm the final cost and availability.</p><p><strong>Important:</strong> This is a front-end demonstration. The enquiry is saved only in this browser; it is not sent to the restaurant until a secure server-side form endpoint is connected.</p>`);
                enquiryForm.reset(); if (dateField) dateField.min = localToday;
            } catch (err) { error.textContent = 'Your enquiry could not be processed in this browser. Please try again.'; }
            finally { submit.disabled = false; submit.textContent = 'Submit Enquiry'; }
        });
    }

    // Leaflet interactive map centred on Mbombela. Marker is approximate, not a verified street address.
    const mapElement = document.getElementById('restaurantMap');
    if (mapElement && window.L) {
        const map = L.map(mapElement).setView([-25.4753, 30.9694], 13);
        L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', { attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors', maxZoom: 19 }).addTo(map);
        L.marker([-25.4753, 30.9694]).addTo(map).bindPopup('<strong>Mbombela area</strong><br>Approximate area only. Confirm the restaurant address before travelling.').openPopup();
    } else if (mapElement) {
        mapElement.textContent = 'The interactive map could not load. Please check your internet connection.';
    }
});
