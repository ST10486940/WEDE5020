# Delicious Bites Restaurant Website – Part 3

## Website proposal

Delicious Bites Restaurant is a restaurant website concept for customers in Mbombela, Mpumalanga. The purpose of the website is to introduce the restaurant, present its meals and dining services, display food photographs, and make it easier for visitors to contact the restaurant or enquire about meals and special orders. The intended audience includes individuals, families, friends and groups looking for a welcoming place to eat. The website uses a nude, brown and white colour palette to create a warm and simple visual identity.

The website contains Home, About, Services, Gallery, Enquiry and Contact pages. It is designed to be responsive on desktop and mobile devices. The contact details and restaurant address are retained from the supplied Part 2 website content and should be verified by the site owner before public launch.

## Pages and features

- `index.html` – restaurant introduction and internal navigation.
- `about.html` – mission, vision and restaurant information.
- `service.html` – service information and JavaScript-powered searchable/filterable meal cards.
- `gallery.html` – responsive photo gallery with a JavaScript lightbox.
- `enquiry.html` – enquiry form for meals, group dining and special requests.
- `contact.html` – general contact form and an interactive Leaflet map centred approximately on Mbombela.

## Part 2 feedback corrections recorded for Part 3

- Wrapped the navigation link list in a semantic `<nav>` element on every page and made the navigation consistent across the website.
- Used a consistent semantic page structure with a `<main>` element, meaningful `<section>` groupings and a shared `<footer>`.
- Corrected heading hierarchy so each page has one primary `<h1>` followed by logical `<h2>` headings.
- Removed inline image sizing attributes and moved presentation rules into the external stylesheet. Images now scale responsively.
- Kept the supplied image files and their original filenames; corrected the contact page image reference to a file that is actually present in the supplied `img` folder.
- Scoped navigation CSS to `nav ul` so that content lists and menu lists do not inherit navigation styling.
- Replaced paragraph-based meal item presentation with semantic list/card structures.
- Removed `<br>` elements used for form layout and used labelled form groups styled with CSS.
- Added descriptive page titles, meta descriptions, keywords, image alternative text and internal links.
- Added the missing `enquiry.html` page to distinguish meal/service enquiries from general contact messages.

## Part 3 functionality and SEO

- JavaScript creates meal cards dynamically and filters them by search text and category on the Services page.
- The Gallery page includes a lightbox with close button, background click and Escape-key support.
- The Contact page includes an interactive Leaflet map using OpenStreetMap tiles. The marker is approximate and must not be treated as a verified street address.
- Contact and enquiry forms include required fields, HTML validation attributes, JavaScript validation, clear error messages and asynchronous client-side processing.
- The enquiry result displays a summary and explains that final pricing and availability must be confirmed with the restaurant.
- Added CSS transitions, responsive layouts, visible keyboard focus styles and descriptive image alt text.
- Added `robots.txt` and `sitemap.xml`. Their placeholder GitHub Pages address must be replaced after deployment.

### Important form limitation

This project is a static HTML/CSS/JavaScript website. The forms currently demonstrate client-side validation and asynchronous browser processing and save demonstration submissions in the visitor's browser using `localStorage`. They do **not** email the restaurant or store submissions on a central server. To receive real submissions, configure a secure form provider (for example, Formspree or FormSubmit) or a server-side endpoint, then update each form's `action` and the JavaScript submission logic. Do not publish real customer information in a public repository.

### Local map and business details

The map is centred on the general Mbombela area, not the exact supplied street address. Confirm the restaurant's exact location and contact details before launch. Leaflet and OpenStreetMap map tiles require an internet connection.

## Running the website

1. Extract the ZIP file.
2. Open the `Delicious_Bites_Part3` folder in Visual Studio Code.
3. Open `index.html` in a browser, or use the Live Server extension.
4. Keep the `css`, `js` and `img` folders in the same location as the HTML files.

## Publishing with GitHub Pages

1. Create or open the GitHub repository for this website.
2. Upload the **contents** of this folder (the HTML files and the `css`, `js` and `img` folders), not the ZIP file itself.
3. Commit the files with a descriptive message such as `Complete Part 3 website functionality and SEO`.
4. In the repository, open **Settings → Pages**. Under Build and deployment, choose **Deploy from a branch**, select the `main` branch and `/ (root)`, then save.
5. Wait for GitHub Pages to publish the website and copy the published address.
6. Replace the placeholder website address in `sitemap.xml` and `robots.txt` with the real published address, commit and push the changes.
7. Test every page, image, form validation message, gallery lightbox and map on the published website.

## Changelog

### Part 3 – 5 November 2026

- Added JavaScript-driven meal content rendering and search/category filtering to improve how visitors browse the restaurant's meal options.
- Added a responsive gallery lightbox so visitors can enlarge food and restaurant photographs and close the viewer using the close control, backdrop or Escape key.
- Added an interactive Leaflet map using OpenStreetMap tiles, centred approximately on Mbombela to provide location context.
- Added a dedicated enquiry page and differentiated it from the general contact page. The enquiry form collects the requested meal/service, details, preferred date and group size; its response summarises the enquiry and explains how to confirm availability and cost.
- Improved the general contact form to collect name, email, optional phone number, message category, subject and full message.
- Added client-side form validation, input constraints, phone/date checks, accessible error and success messages, and asynchronous browser-side demonstration processing.
- Added responsive CSS layouts, focus indicators, hover transitions, form styling and gallery presentation.
- Added SEO page titles, meta descriptions, keyword metadata, semantic headings, internal links and descriptive image alternative text.
- Added `robots.txt` and `sitemap.xml` to support search engine crawling after the published URL placeholders are updated.
- Added this README section documenting the proposal, functionality, feedback corrections, limitations and deployment process.

### Part 2 feedback corrections – 5 November 2026

- Corrected the navigation markup on all pages by placing the navigation list inside a semantic `<nav>` element.
- Standardised the main content and footer structure across the website and grouped related information into semantic sections.
- Corrected heading order and ensured each page uses a primary `<h1>` heading.
- Removed inline width attributes from images and applied responsive image sizing in `css/style.css`. Original image filenames were retained.
- Updated CSS selectors so navigation list styles do not affect ordinary content lists.
- Presented meal choices using semantic list/card markup rather than separate paragraph elements.
- Reworked contact form layout using labelled form groups and CSS instead of line-break elements.
- Corrected the broken contact-page image path to reference an image file included in the supplied image folder.

## References

- Google Search Central (n.d.) *SEO Starter Guide*. Available at: https://developers.google.com/search/docs/fundamentals/seo-starter-guide (Accessed: 5 November 2026).
- MDN Web Docs (n.d.) *HTML forms*. Available at: https://developer.mozilla.org/en-US/docs/Learn_web_development/Extensions/Forms (Accessed: 5 November 2026).
- MDN Web Docs (n.d.) *Client-side form validation*. Available at: https://developer.mozilla.org/en-US/docs/Learn_web_development/Extensions/Forms/Form_validation (Accessed: 5 November 2026).
- MDN Web Docs (n.d.) *Using the Fetch API*. Available at: https://developer.mozilla.org/en-US/docs/Web/API/Fetch_API/Using_Fetch (Accessed: 5 November 2026).
- Leaflet (n.d.) *Leaflet – a JavaScript library for interactive maps*. Available at: https://leafletjs.com/ (Accessed: 5 November 2026).
- OpenStreetMap (n.d.) *Copyright and licence*. Available at: https://www.openstreetmap.org/copyright (Accessed: 5 November 2026).
- GitHub Docs (n.d.) *What is GitHub Pages?*. Available at: https://docs.github.com/en/pages/getting-started-with-github-pages/what-is-github-pages (Accessed: 5 November 2026).

## Before final submission

- Replace the placeholder GitHub Pages URL in `robots.txt` and `sitemap.xml`.
- Configure a real secure form endpoint if the lecturer expects submissions to reach an inbox or server.
- Verify the restaurant's contact details and exact map location.
- Add any required student name, student number, module details and repository URL if your lecturer's submission format requests them.
- Commit and push all final changes to the GitHub repository.
