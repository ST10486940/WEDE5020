/*
    Delicious Bites Restaurant
    WEDE5020 - Part 3
    JavaScript Functionality
*/

"use strict";

document.addEventListener("DOMContentLoaded", function () {

    // =====================================
    // 1. RESPONSIVE NAVIGATION MENU
    // =====================================

    const navToggle = document.querySelector(".nav-toggle");
    const navigation = document.querySelector(".site-nav");

    if (navToggle && navigation) {

        navToggle.addEventListener("click", function () {

            const isOpen = navigation.classList.toggle("open");

            navToggle.setAttribute(
                "aria-expanded",
                String(isOpen)
            );

            navToggle.setAttribute(
                "aria-label",
                isOpen ? "Close navigation" : "Open navigation"
            );
        });
    }


    // =====================================
    // 2. MENU SEARCH AND FILTER
    // =====================================

    const menuSearch = document.getElementById("menu-search");
    const menuCards = document.querySelectorAll(".menu-card");
    const menuMessage = document.getElementById("menu-message");

    if (menuSearch) {

        menuSearch.addEventListener("input", function () {

            const searchValue = menuSearch.value.toLowerCase().trim();
            let resultsFound = 0;

            menuCards.forEach(function (card) {

                const mealName = card.dataset.name.toLowerCase();

                if (mealName.includes(searchValue)) {

                    card.hidden = false;
                    resultsFound++;

                } else {

                    card.hidden = true;

                }
            });

            if (menuMessage) {

                if (resultsFound > 0) {
                    menuMessage.textContent =
                        resultsFound + " menu item(s) found.";
                } else {
                    menuMessage.textContent =
                        "Sorry, no matching meals were found.";
                }
            }
        });
    }


    // =====================================
    // 3. IMAGE GALLERY LIGHTBOX
    // =====================================

    const galleryItems = document.querySelectorAll(".gallery-item");
    const lightbox = document.getElementById("lightbox");
    const lightboxImage = document.getElementById("lightbox-image");
    const closeButton = document.querySelector(".lightbox-close");

    galleryItems.forEach(function (item) {

        item.addEventListener("click", function () {

            if (!lightbox || !lightboxImage) return;

            const image = item.querySelector("img");

            lightboxImage.src = item.dataset.full || image.src;
            lightboxImage.alt = image.alt;

            lightbox.classList.add("open");
            lightbox.setAttribute("aria-hidden", "false");

            if (closeButton) {
                closeButton.focus();
            }
        });
    });

    function closeLightbox() {

        if (!lightbox || !lightboxImage) return;

        lightbox.classList.remove("open");
        lightbox.setAttribute("aria-hidden", "true");

        lightboxImage.src = "";
    }

    if (closeButton) {

        closeButton.addEventListener("click", closeLightbox);

    }

    if (lightbox) {

        lightbox.addEventListener("click", function (event) {

            if (event.target === lightbox) {
                closeLightbox();
            }
        });

    }

    document.addEventListener("keydown", function (event) {

        if (event.key === "Escape") {
            closeLightbox();
        }

    });


    // =====================================
    // 4. CONTACT AND ENQUIRY FORM VALIDATION
    // =====================================

    const forms = document.querySelectorAll(".site-form");

    forms.forEach(function (form) {

        form.addEventListener("submit", function (event) {

            event.preventDefault();

            const messageBox = form.querySelector(".form-message");

            // Check that all required information is correct
            if (!form.reportValidity()) {

                if (messageBox) {
                    messageBox.textContent =
                        "Please complete all required fields correctly.";
                    messageBox.classList.add("error");
                }

                return;
            }

            const formData = new FormData(form);

            const name = formData.get("name");
            const email = formData.get("email");

            let subject;
            let body;

            // Prepare contact form information
            if (form.dataset.formType === "contact") {

                const messageType = formData.get("messageType");
                const message = formData.get("message");

                subject = "Website Message: " + messageType;

                body =
                    "Name: " + name + "\n" +
                    "Email: " + email + "\n" +
                    "Message Type: " + messageType + "\n\n" +
                    "Message:\n" + message;

            }

            // Prepare enquiry form information
            else if (form.dataset.formType === "enquiry") {

                const phone = formData.get("phone") || "Not provided";
                const topic = formData.get("topic");
                const details = formData.get("details");

                subject = "Restaurant Enquiry: " + topic;

                body =
                    "Name: " + name + "\n" +
                    "Email: " + email + "\n" +
                    "Telephone: " + phone + "\n" +
                    "Topic: " + topic + "\n\n" +
                    "Enquiry Details:\n" + details;

            }

            // Display successful validation message
            if (messageBox) {

                messageBox.textContent =
                    "Your information is valid. Thank you!";

                messageBox.classList.remove("error");
            }

            // Replace this with the restaurant's real email address
            const restaurantEmail =
                "YOUR-EMAIL@example.com";

            if (restaurantEmail === "YOUR-EMAIL@example.com") {

                if (messageBox) {
                    messageBox.textContent =
                        "Form validated successfully. Add the restaurant's real email address in script.js to prepare an email.";
                }

                return;
            }

            // Open the visitor's email application
            const mailLink =
                "mailto:" + restaurantEmail +
                "?subject=" + encodeURIComponent(subject) +
                "&body=" + encodeURIComponent(body);

            window.location.href = mailLink;

        });

    });


    // =====================================
    // 5. BACK TO TOP FUNCTION
    // =====================================

    const backToTop = document.getElementById("back-to-top");

    if (backToTop) {

        backToTop.addEventListener("click", function () {

            window.scrollTo({
                top: 0,
                behavior: "smooth"
            });

        });

    }


    // =====================================
    // 6. CURRENT YEAR IN FOOTER
    // =====================================

    const yearElements = document.querySelectorAll(".current-year");

    yearElements.forEach(function (element) {

        element.textContent = new Date().getFullYear();

    });


    // =====================================
    // 7. WELCOME MESSAGE
    // =====================================

    const welcomeMessage = document.getElementById("welcome-message");

    if (welcomeMessage) {

        welcomeMessage.textContent =
            "Welcome to Delicious Bites Restaurant! Enjoy our delicious meals.";

    }

});